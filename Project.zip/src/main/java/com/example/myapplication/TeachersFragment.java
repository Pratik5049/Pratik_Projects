package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.TextUtils;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.Model.Department;
import com.example.myapplication.Model.Task;
import com.example.myapplication.Model.Users;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Objects;

public class TeachersFragment extends Fragment {
    ArrayList<Users> recyclerViewList = new ArrayList<>();
    ArrayList<String> departmentNameArrayList = new ArrayList<>();
    ArrayList<Department> departmentArrayList = new ArrayList<>();
    RecyclerView recyclerView;
    FloatingActionButton AddUserButton;
    TeachersRecyclerApapter teachersRecyclerApapter;
    private FirebaseAuth mAuth;
    private FirebaseDatabase database;
    Dialog dialog;
    Users CurrentUser;

    public TeachersFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
      View view = inflater.inflate(R.layout.fragment_teachers, container, false);
        recyclerView = view.findViewById(R.id.teacher_recview);
        AddUserButton = view.findViewById(R.id.floatingActionButtonAddUser);
        //this is firebase database operations
        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        setupRecyclerView();
        GetCurrentUser();
        GetAllUsers();
        fetchDepartments();
        AddUserButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAddUserDialog();
            }
        });
        return view;

    }
    private void setupRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        teachersRecyclerApapter = new TeachersRecyclerApapter(getContext(), recyclerViewList);
        recyclerView.setAdapter(teachersRecyclerApapter);
    }
    private void openAddUserDialog() {
        try {
            // Create and show the dialog
            dialog = new Dialog(getContext(), android.R.style.Theme_Translucent_NoTitleBar);
            dialog.setContentView(R.layout.popup_add_user);
            dialog.setCanceledOnTouchOutside(false);
            dialog.show();
            View dialogRootView = dialog.findViewById(R.id.IdAddUserPopup); // Replace with the actual ID of your root view
            dialogRootView.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    // Consume the touch event to prevent it from reaching the underlying views
                    return true;
                }
            });
            TextView dialogCloseTextVeiw = dialog.findViewById(R.id.dlg_TVClose);
            dialogCloseTextVeiw.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    TeacherPopupDialogClose();
                }
            });
            ArrayList<String> RoleList = new ArrayList<>();

            // Department
            Spinner autoCompleteTextView = dialog.findViewById(R.id.addUserPopup_department_name);
            ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(), android.R.layout.select_dialog_item, departmentNameArrayList);
            autoCompleteTextView.setAdapter(adapter);

            RoleList.clear();

            if (CurrentUser.getRoleName().equals("HOD")) {
                // If the current user is an HOD, hide the department section and add "Teacher" role
                CardView department = dialog.findViewById(R.id.popup_add_user_cardView_DepartmentSection);
                department.setVisibility(View.GONE);
                RoleList.add("Teacher");
            } else {
                // If the current user is not an HOD, add both "HOD" and "Teacher" roles
                RoleList.add("HOD");
                RoleList.add("Teacher");
            }

            ArrayAdapter<String> adapter1 = new ArrayAdapter<>(getContext(), android.R.layout.select_dialog_item, RoleList);
            Spinner roleCompleteTextView = dialog.findViewById(R.id.addUserPopup_RoleName);
            roleCompleteTextView.setAdapter(adapter1);

            Button save = dialog.findViewById(R.id.addUserPopup_Save);
            save.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    EditText username = dialog.findViewById(R.id.addUserPopup_UserName);
                    EditText Email = dialog.findViewById(R.id.addUserPopup_email);
                    EditText Password = dialog.findViewById(R.id.addUserPopup_password);

                    // Perform basic validation
                    String usernameStr = username.getText().toString();
                    String emailStr = Email.getText().toString();
                    String passwordStr = Password.getText().toString();

                    if (usernameStr.isEmpty() || emailStr.isEmpty() || passwordStr.isEmpty()) {
                        Toast.makeText(getContext(), "Please fill in all fields", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (!isValidEmail(emailStr)) {
                        Toast.makeText(getContext(), "Invalid email address", Toast.LENGTH_LONG).show();
                        return;
                    }

                    // Create a new user with the provided information
                    Users users = new Users();
                    users.setEmail(emailStr);
                    users.setName(usernameStr);
                    users.setPassword(passwordStr);
                    users.setRoleName(roleCompleteTextView.getSelectedItem().toString());
                    Department selectedDepartment = null;

                    if (CurrentUser.getRoleName().equals("HOD")) {
                        // If the current user is an HOD, use their department
                        selectedDepartment = CurrentUser.getDepartment();
                    } else {
                        // If not an HOD, get the selected department
                        String selectedDepartmentName = autoCompleteTextView.getSelectedItem().toString();

                        for (Department department : departmentArrayList) {
                            if (department.getName().equals(selectedDepartmentName)) {
                                selectedDepartment = department;
                                break;
                            }
                        }
                    }
                    users.setDepartment(selectedDepartment);

                    // Create a new user account with Firebase Authentication
                    mAuth.createUserWithEmailAndPassword(emailStr, passwordStr).addOnCompleteListener(createAccountTask -> {
                        if (createAccountTask.isSuccessful()) {
                            // New user account created successfully
                            FirebaseUser newUser = createAccountTask.getResult().getUser();
                            String newUserId = newUser.getUid();
                            users.setId(newUserId);

                            // Store user information in the database
                            database.getReference().child("Users").child(newUserId).setValue(users);

                            // Sign in the current admin user again
                            mAuth.signInWithEmailAndPassword(CurrentUser.getEmail(), CurrentUser.getPassword());

                            Toast.makeText(getContext(), "Account is created", Toast.LENGTH_SHORT).show();
                            TeacherPopupDialogClose();
                        } else {
                            Toast.makeText(getContext(), "Error: " + Objects.requireNonNull(createAccountTask.getException()).getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            });


        } catch (Exception exception) {
            Toast.makeText(getContext(), exception.getMessage().toString(), Toast.LENGTH_LONG).show();
        }
    }
    private void GetAllUsers( ){
        try{
            database.getReference().child("Users").addValueEventListener(new ValueEventListener() {
                @SuppressLint("NotifyDataSetChanged")
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    try{
                        recyclerViewList.clear();
                        for (DataSnapshot data : snapshot.getChildren()) {
                            Users users = data.getValue(Users.class);

                            if(CurrentUser.getRoleName().equalsIgnoreCase("HOD")) {
                               if(CurrentUser.getDepartment().getName().equalsIgnoreCase(users.getDepartment().getName())){
                                   recyclerViewList.add(users);
                               }
                            }else{
                                recyclerViewList.add(users);
                            }
                        }
                        teachersRecyclerApapter.notifyDataSetChanged();
                    }catch (Exception exception){
                        Toast.makeText(getContext(), exception.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });
        }catch (Exception exception){
            Toast.makeText(getContext(), exception.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    private boolean isValidEmail(CharSequence target) {
        return !TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }
    private void fetchDepartments() {
        database.getReference().child("Department").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                departmentArrayList.clear();
                departmentNameArrayList.clear();
                for (DataSnapshot data : snapshot.getChildren()) {
                    Department department = data.getValue(Department.class);
                    if (department != null) {
                        departmentArrayList.add(department);
                        departmentNameArrayList.add(department.getName());
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle errors here
            }
        });
    }

    private  void  GetCurrentUser(){
        try {
            database = FirebaseDatabase.getInstance();
            database.getReference().child("Users").child(Objects.requireNonNull(mAuth.getUid())).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    try{
                        CurrentUser = snapshot.getValue(Users.class);
                        if(CurrentUser.getRoleName().equalsIgnoreCase("Teacher")){
                            AddUserButton.setVisibility(View.GONE);
                        }
                    }catch (Exception exception){
                        Toast.makeText(getContext(), exception.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });
        }catch (Exception exception){
            Toast.makeText(getContext(), exception.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    public void TeacherPopupDialogClose(){
        dialog.dismiss();
    }
}