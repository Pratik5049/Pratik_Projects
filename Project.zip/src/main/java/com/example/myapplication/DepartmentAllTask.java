package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.Model.Department;
import com.example.myapplication.Model.Task;
import com.example.myapplication.Model.Users;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class DepartmentAllTask extends AppCompatActivity {
    FirebaseDatabase database;
    TextView department;
    RecyclerView recyclerViewTask;
    ArrayList<Task> recyclerViewList = new ArrayList<>();
    myadapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_department_all_task);
        String Department = getIntent().getExtras().getString("DepartmentId");
        initializeUI();
        setupRecyclerView();
        department.setText(Department);
        try {
            database = FirebaseDatabase.getInstance();

                database.getReference().child("Task").addValueEventListener(new ValueEventListener() {
                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        try{
                            recyclerViewList.clear();
                            for (DataSnapshot data : snapshot.getChildren()) {
                                Task task = data.getValue(Task.class);
                                if (task != null && task.getDepartment() != null) {
                                    for (com.example.myapplication.Model.Department department : task.getDepartment()) {
                                        if (department.getName().equals(Department)) {
                                            recyclerViewList.add(task);
                                        }
                                    }
                                }
                            }
                            adapter.notifyDataSetChanged();
                        }catch (Exception exception){
                            Toast.makeText(DepartmentAllTask.this, exception.getMessage(), Toast.LENGTH_LONG).show();
                            Log.d("GANESH",exception.getMessage());
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });

        }catch (Exception exception){
            Toast.makeText(this, exception.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void setupRecyclerView() {
        recyclerViewTask.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        adapter = new myadapter(DepartmentAllTask.this, recyclerViewList);
        recyclerViewTask.setAdapter(adapter);
    }
    private void initializeUI() {
        department = findViewById(R.id.Department_All_Task_DepartmentName);
        recyclerViewTask = findViewById(R.id.Department_All_Task_recyclerView);
    }
}