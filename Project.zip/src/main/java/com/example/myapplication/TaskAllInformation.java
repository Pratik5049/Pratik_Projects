package com.example.myapplication;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.Model.Department;
import com.example.myapplication.Model.Task;

import com.example.myapplication.Model.Users;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class TaskAllInformation extends AppCompatActivity {
    FirebaseDatabase database;
    private FirebaseAuth mAuth;
    Dialog dialog;
    private Uri selectedFileUri;
    private TextView selectedFileTextView;
    private static final int REQUEST_FILE_PICKER = 1;
    ArrayList<Users> UsersList = new ArrayList<>();
    Users CurrentUser;
    Task task;
    String TaskID;
    Button deleteTask;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_all_information);


        TaskID= getIntent().getExtras().getString("TaskID");
        TextView taskName = findViewById(R.id.taskAllInfo_taksName);
        TextView taskNote = findViewById(R.id.taskAllInfo_Note);
        TextView departments = findViewById(R.id.taskAllInfo_DepartementNames);
        TextView assign = findViewById(R.id.taskAllInfo_AssignTeacherName);
        TextView taskAllInfo_TaskStartDate = findViewById(R.id.taskAllInfo_TaskStartDate);
        TextView taskAllInfo_TasKEndDate = findViewById(R.id.taskAllInfo_TasKEndDate);
        TextView task_all_info_status = findViewById(R.id.task_all_info_status);
        TextView task_all_info_description = findViewById(R.id.task_all_info_description);
        deleteTask = findViewById(R.id.task_all_info_deleteTask);
        assign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(TaskAllInformation.this, AssingUserInfoActivity.class);
                intent.putExtra("assignUserID",task.getUsers().getId());
                startActivity(intent);
            }
        });
        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        database.getReference().child("Task").child(TaskID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                try {
                    task = snapshot.getValue(Task.class);
                    taskName.setText(task.getName());
                    taskNote.setText(task.getNote());
                    if (task.getUsers() == null) {
                        assign.setText("-");
                    } else{
                        SpannableString content = new SpannableString(task.getUsers().getName());
                        content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
                        content.setSpan(new ForegroundColorSpan(Color.BLUE), 0, content.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                        assign.setText(content);
                    }
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

                    String startDateString = dateFormat.format(task.getStartDate());
                    String endDateString = dateFormat.format(task.getEndDate());
                    taskAllInfo_TasKEndDate.setText(endDateString);
                    taskAllInfo_TaskStartDate.setText(startDateString);
                    task_all_info_status.setText(task.getStatus());
                    task_all_info_description.setText(task.getDescription());
                    String stringDepartment ="";
                    for (Department department : task.getDepartment()) {
                        stringDepartment += department.getName() +",";
                    }
                    departments.setText(stringDepartment);

                    Button task_all_info_viewDoc_btn = findViewById(R.id.task_all_info_viewDoc_btn1);
                    if (task.getFileUrl() == null) {
                        task_all_info_viewDoc_btn.setVisibility(View.GONE);
                    } else {
                        task_all_info_viewDoc_btn.setVisibility(View.VISIBLE);
                        task_all_info_viewDoc_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Uri fileUri = Uri.parse(task.getFileUrl());
                                Intent intent = new Intent(Intent.ACTION_VIEW, fileUri);
                                startActivity(intent);
                            }
                        });
                    }
                }catch (Exception exception){
                    Toast.makeText(TaskAllInformation.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        GetCurrentUser();

        GetAllUser();

        deleteTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(TaskAllInformation.this);
                builder.setMessage("Are you sure you want to delete this task?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // User clicked "Yes", delete the task
                                DatabaseReference taskRef = database.getReference().child("Task").child(TaskID);
                                taskRef.removeValue()
                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                Toast.makeText(TaskAllInformation.this, "Task is deleted successfully", Toast.LENGTH_SHORT).show();
                                                Intent intent = new Intent(TaskAllInformation.this, MainActivity.class);
                                                startActivity(intent);
                                                finish();
                                            }
                                        })
                                        .addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                // Handle the error, e.g., show a message to the user
                                                Toast.makeText(TaskAllInformation.this, "Failed to delete task: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                            }
                                        });
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // User clicked "No," do nothing, and close the dialog
                            }
                        });
                builder.create().show();
            }
        });

        Button editTask = findViewById(R.id.task_all_info_editTask);
        editTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dialog = new Dialog(TaskAllInformation.this, android.R.style.Theme_Translucent_NoTitleBar);
                dialog.setContentView(R.layout.popup_add_task);
                dialog.show();

                EditText taskName = dialog.findViewById(R.id.addTaskPopup_taskName);
                taskName.setText(task.getName());
                EditText note = dialog.findViewById(R.id.addTaskPopup_Note);
                note.setText(task.getNote());

                //Department
                CardView cardView = dialog.findViewById(R.id.popup_add_task_cardView_department);
                CardView performedEndDate = dialog.findViewById(R.id.performedEndDateCardView);
                CardView performedStartDate = dialog.findViewById(R.id.performedStartDateCardView);
                cardView.setVisibility(View.GONE);
                if(CurrentUser.getRoleName().equalsIgnoreCase("HOD") || CurrentUser.getRoleName().equalsIgnoreCase("Teacher") ){
                    performedEndDate.setVisibility(View.VISIBLE);
                    performedStartDate.setVisibility(View.VISIBLE);
                }

                if(CurrentUser.getRoleName().equals("HOD")){
                    CardView cardView1 =dialog.findViewById(R.id.popup_add_task_cardView_assing);
                    cardView1.setVisibility(View.VISIBLE);
                }
                ArrayList<String> DepartmentTeacherList = new ArrayList<>();
                for (Users users: UsersList) {
                    if(users.getDepartment().getName().equals(CurrentUser.getDepartment().getName())){
                        DepartmentTeacherList.add(users.getName());
                    }
                }
                ArrayAdapter<String> adapter1 = new ArrayAdapter<>(TaskAllInformation.this, android.R.layout.select_dialog_item,DepartmentTeacherList );
                Spinner AssingCompleteTextView = dialog.findViewById(R.id.popup_add_task_assing);
                AssingCompleteTextView.setAdapter(adapter1);

                //Start and End date
                EditText startDate = dialog.findViewById(R.id.startDateEditText);
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String startDateString = dateFormat.format(task.getStartDate());
                String endDateString = dateFormat.format(task.getEndDate());
                startDate.setText(startDateString);
                startDate.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        showDatePickerDialog(startDate);
                    }
                });
                EditText endDate = dialog.findViewById(R.id.endDateEditText);
                endDate.setText(endDateString);
                endDate.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        showDatePickerDialog(endDate);
                    }
                });

                EditText performedEndDateEdit = dialog.findViewById(R.id.performedEndDateEditText);
                if(task.getPerformedEndDate() != null){
                    performedEndDateEdit.setText(dateFormat.format(task.getPerformedEndDate()));
                }
                EditText performedStartDateEdit = dialog.findViewById(R.id.PerformedstartDateEditText);
                if(task.getPerformedStartDate() != null){
                    performedStartDateEdit.setText(dateFormat.format(task.getPerformedStartDate()));
                }
                performedStartDateEdit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        showDatePickerDialog(performedStartDateEdit);
                    }
                });
                performedEndDateEdit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        showDatePickerDialog(performedEndDateEdit);
                    }
                });

                //File get
                selectedFileTextView = dialog.findViewById(R.id.selectedFileTextView);
                if (task.getFileUrl() != null) {
                    selectedFileTextView.setText("Selected File: " + task.getFileUrl());
                }
                Button button = dialog.findViewById(R.id.selectFileButton);
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        openFilePicker();
                    }
                });

                //Description
                EditText description = dialog.findViewById(R.id.popup_add_task_Description);
                description.setText(task.getDescription());
                // Status
                EditText status = dialog.findViewById(R.id.popup_add_task_status);
                status.setText(task.getStatus());
                //Save task
                Button saveTask = dialog.findViewById(R.id.save_popupAddTask);
                saveTask.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        try {
                            Task task1 = task;
                            // Get the values from the input fields
                            String taskNameStr = taskName.getText().toString().trim();
                            String noteStr = note.getText().toString().trim();
                            String startDateStr = startDate.getText().toString().trim();
                            String endDateStr = endDate.getText().toString().trim();
                            String statusStr = endDate.getText().toString().trim();
                            String performedstartDateStr = performedStartDateEdit.getText().toString().trim();
                            String performedendDateStr = performedEndDateEdit.getText().toString().trim();

                            if (taskNameStr.isEmpty() || startDateStr.isEmpty() || endDateStr.isEmpty() || noteStr.isEmpty()|| statusStr.isEmpty()) {
                                Toast.makeText(TaskAllInformation.this, "Please fill in all required fields", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            task1.setName(taskName.getText().toString());
                            task1.setNote(note.getText().toString());
                            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                            Date date = dateFormat.parse(startDate.getText().toString());
                            task1.setStartDate(date);
                            date = dateFormat.parse(endDate.getText().toString());
                            task1.setEndDate(date);
                            task1.setDescription(description.getText().toString());
                            task1.setStatus(status.getText().toString());
                            if(performedstartDateStr.isEmpty() == false){
                                date= dateFormat.parse(performedstartDateStr);
                                task1.setPerformedStartDate(date);
                            }
                            if(performedendDateStr.isEmpty() == false) {
                                date = dateFormat.parse(performedendDateStr);
                                task1.setPerformedEndDate(date);
                            }
                            if (CurrentUser.getRoleName().equals("HOD")) {
                                // Get the selected value from the spinner
                                String selectedValue = AssingCompleteTextView.getSelectedItem().toString();
                                // Initialize a selectedUser variable to null
                                Users selectedUser = null;
                                // Iterate through the UsersList to find the user with the selected value
                                for (Users user : UsersList) {
                                    if (user.getName().equals(selectedValue)) { // Assuming you want to match by user name
                                        selectedUser = user;
                                        break; // Exit the loop once a match is found
                                    }
                                }
                                // Check if a user with the selected value was found
                                if (selectedUser != null) {
                                    // Set the selected user in your task object
                                    task.setUsers(selectedUser);
                                } else {
                                    // Handle the case where no matching user is found
                                    Toast.makeText(TaskAllInformation.this, "No user found with the selected value", Toast.LENGTH_SHORT).show();
                                }

                            }
                            if (selectedFileUri != null) {
                                uploadFileToFirebase(selectedFileUri, task);
                            } else {
                                insertTask(task);
                            }
                            dialog.dismiss();
                        } catch (Exception exception) {
                            Toast.makeText(TaskAllInformation.this, exception.getMessage().toString(), Toast.LENGTH_LONG).show();
                        }
                    }
                });

            }
        });



    }
    private void GetAllUser(){
        try {
            database = FirebaseDatabase.getInstance();
            database.getReference().child("Users").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    try{
                        UsersList.clear();
                        for (DataSnapshot data : snapshot.getChildren()) {
                            Users users = data.getValue(Users.class);
                            UsersList.add(users);
                        }
                    }catch (Exception exception){
                        Toast.makeText(TaskAllInformation.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });
        }catch (Exception exception){
            Toast.makeText(this, exception.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    private  void  GetCurrentUser(){
        try {
            database = FirebaseDatabase.getInstance();
            database.getReference().child("Users").child(mAuth.getUid().toString()).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    try{
                        CurrentUser = snapshot.getValue(Users.class);
                        if(CurrentUser.getRoleName().equals("Teacher")){
                            deleteTask.setVisibility(View.GONE);
                        }
                    }catch (Exception exception){
                        Toast.makeText(TaskAllInformation.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });
        }catch (Exception exception){
            Toast.makeText(this, exception.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    private void insertTask(Task task){
        database.getReference().child("Task").child(TaskID).setValue(task);
        Toast.makeText(TaskAllInformation.this, "Task updated successfully", Toast.LENGTH_SHORT).show();
    }
    private void uploadFileToFirebase(Uri fileUri, final Task task) {
        StorageReference FileFolder = FirebaseStorage.getInstance().getReference().child("your_folder");
        StorageReference fileRef = FileFolder.child("file" + fileUri.getLastPathSegment());

        // Upload the file to Firebase Storage
        fileRef.putFile(fileUri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        // File successfully uploaded, now get the download URL
                        fileRef.getDownloadUrl()
                                .addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri downloadUrl) {
                                        // 'downloadUrl' contains the URL of the uploaded file
                                        String fileUrl = downloadUrl.toString();
                                        // Set the file URL in the task object
                                        task.setFileUrl(fileUrl);
                                        insertTask(task);
                                        Toast.makeText(TaskAllInformation.this, "File uploaded successfully. URL: " + fileUrl, Toast.LENGTH_SHORT).show();
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        // Handle the failure to get the download URL
                                        Toast.makeText(TaskAllInformation.this, "Failed to get download URL: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                    }
                                });
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // Handle the failure to upload the file
                        Toast.makeText(TaskAllInformation.this, "File upload failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if (requestCode == REQUEST_FILE_PICKER && resultCode == RESULT_OK) {
                if (data != null) {
                    selectedFileUri = data.getData();
                    // Now you have the URI of the selected file, and you can proceed with file upload.

                    String selectedFileName = getFileNameFromUri(selectedFileUri);
                    selectedFileTextView.setText("Selected File: " + selectedFileName);
                }
            }
        } catch (Exception exception) {
            Toast.makeText(this, exception.getMessage().toString(), Toast.LENGTH_SHORT).show();
        }
    }
    private String getFileNameFromUri(Uri uri) {
        String fileName = "";
        if (uri.getScheme().equals("content")) {
            Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            try {
                if (cursor != null && cursor.moveToFirst()) {
                    fileName = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                }
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        return fileName;
    }
    private void showDatePickerDialog(final EditText editText) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(android.widget.DatePicker view, int year, int month, int dayOfMonth) {
                        // The selected date is returned here
                        String selectedDate = year + "-" + (month + 1) + "-" + dayOfMonth;
                        editText.setText(selectedDate);
                    }
                },
                year, month, day
        );
        datePickerDialog.show();
    }
    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*"); // All file types
        intent.addCategory(Intent.CATEGORY_OPENABLE);

        startActivityForResult(intent, REQUEST_FILE_PICKER);
    }

    public void dialogClose(View view){
        dialog.dismiss();
    }
}