package com.example.myapplication.Model;

public class Token {
    String Token;

    public Token() {
    }

    public Token(String token) {
        Token = token;
    }

    public String getToken() {
        return Token;
    }

    public void setToken(String token) {
        Token = token;
    }
}
