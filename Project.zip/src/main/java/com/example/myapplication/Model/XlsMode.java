package com.example.myapplication.Model;


public class XlsMode {
    String Index;
    String Department;
    String UserName;
    String TaskName;
    String StartDate;
    String EndDate;
    String Status;
    String FileUrl;

    public XlsMode() {
    }

    public XlsMode(String index, String department, String userName, String taskName, String startDate, String endDate, String report, String fileUrl) {
        Index = index;
        Department = department;
        UserName = userName;
        TaskName = taskName;
        StartDate = startDate;
        EndDate = endDate;
        Status = report;
        FileUrl = fileUrl;
    }

    public String getReport() {
        return Status;
    }

    public void setReport(String report) {
        Status = report;
    }

    public String getDepartment() {
        return Department;
    }

    public void setDepartment(String department) {
        Department = department;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public String getTaskName() {
        return TaskName;
    }

    public void setTaskName(String taskName) {
        TaskName = taskName;
    }

    public String getStartDate() {
        return StartDate;
    }

    public void setStartDate(String startDate) {
        StartDate = startDate;
    }

    public String getEndDate() {
        return EndDate;
    }

    public void setEndDate(String endDate) {
        EndDate = endDate;
    }

    public String getFileUrl() {
        return FileUrl;
    }

    public void setFileUrl(String fileUrl) {
        FileUrl = fileUrl;
    }
}
