package com.example.myapplication.Model;

public class ReportExport {
    String Index;
    String DepartmentName;
    String TaskName;
    String AssignUserName;
    String PlanedStartDate;
    String PlanedEndDate;
    String PerformedStartDate;
    String PerformedEndDate;
    String Consistency;

    public ReportExport() {
    }

    public ReportExport(String index,String departmentName, String taskName, String assignUserName, String planedStartDate, String planedEndDate, String performedStartDate, String performedEndDate, String consistency) {
        Index = index;
        DepartmentName = departmentName;
        TaskName = taskName;
        AssignUserName = assignUserName;
        PlanedStartDate = planedStartDate;
        PlanedEndDate = planedEndDate;
        PerformedStartDate = performedStartDate;
        PerformedEndDate = performedEndDate;
        Consistency = consistency;
    }

    public String getDepartmentName() {
        return DepartmentName;
    }

    public void setDepartmentName(String departmentName) {
        DepartmentName = departmentName;
    }

    public String getTaskName() {
        return TaskName;
    }

    public void setTaskName(String taskName) {
        TaskName = taskName;
    }

    public String getAssignUserName() {
        return AssignUserName;
    }

    public void setAssignUserName(String assignUserName) {
        AssignUserName = assignUserName;
    }

    public String getPlanedStartDate() {
        return PlanedStartDate;
    }

    public void setPlanedStartDate(String planedStartDate) {
        PlanedStartDate = planedStartDate;
    }

    public String getPlanedEndDate() {
        return PlanedEndDate;
    }

    public void setPlanedEndDate(String planedEndDate) {
        PlanedEndDate = planedEndDate;
    }

    public String getPerformedStartDate() {
        return PerformedStartDate;
    }

    public void setPerformedStartDate(String performedStartDate) {
        PerformedStartDate = performedStartDate;
    }

    public String getPerformedEndDate() {
        return PerformedEndDate;
    }

    public void setPerformedEndDate(String performedEndDate) {
        PerformedEndDate = performedEndDate;
    }

    public String getConsistency() {
        return Consistency;
    }

    public void setConsistency(String consistency) {
        Consistency = consistency;
    }
}
