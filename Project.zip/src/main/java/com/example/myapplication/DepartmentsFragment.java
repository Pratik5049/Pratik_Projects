package com.example.myapplication;

import android.app.Dialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.Model.Department;
import com.example.myapplication.Model.Task;
import com.example.myapplication.Model.Users;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Objects;

public class DepartmentsFragment extends Fragment {
    ArrayList<Department> departmentArrayList = new ArrayList<>();
    RecyclerView recyclerView;
    FloatingActionButton AddDepartmentButton;
    DepartmentRecyclerAdapter departmentRecyclerAdapter;

    private FirebaseDatabase database;
    FirebaseAuth mAuth;
    Dialog dialog;
    Users CurrentUser;

    public DepartmentsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        try {
            View view = inflater.inflate(R.layout.fragment_department, container, false);
            AddDepartmentButton = view.findViewById(R.id.floatingActionButtonAddDepartment);
            recyclerView = view.findViewById(R.id.department_recview);
            database = FirebaseDatabase.getInstance();
            mAuth = FirebaseAuth.getInstance();
            setupRecyclerView();
            GetCurrentUser();
            fetchDepartments();

            AddDepartmentButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openAddDepartmentDialog();
                }
            });
            return view;
        } catch (Exception exception) {
            Toast.makeText(getContext(), "" + exception.getMessage().toString(), Toast.LENGTH_SHORT).show();
        }
        return null;
    }

    private void setupRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        departmentRecyclerAdapter = new DepartmentRecyclerAdapter(getContext(), departmentArrayList);
        recyclerView.setAdapter(departmentRecyclerAdapter);
    }

    private void fetchDepartments() {
        database.getReference().child("Department").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                departmentArrayList.clear();
                for (DataSnapshot data : snapshot.getChildren()) {
                    Department department = data.getValue(Department.class);
                    departmentArrayList.add(department);
                }
                departmentRecyclerAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle errors here
            }
        });
    }

    private void GetCurrentUser() {
        try {
            database = FirebaseDatabase.getInstance();
            database.getReference().child("Users").child(Objects.requireNonNull(mAuth.getUid())).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    try {
                        CurrentUser = snapshot.getValue(Users.class);
                        if (CurrentUser.getRoleName().equalsIgnoreCase("Teacher") || CurrentUser.getRoleName().equalsIgnoreCase("HOD")) {
                            AddDepartmentButton.setVisibility(View.GONE);
                        }
                    } catch (Exception exception) {
                        Toast.makeText(getContext(), exception.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });
        } catch (Exception exception) {
            Toast.makeText(getContext(), exception.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void openAddDepartmentDialog() {
        try {
            dialog = new Dialog(getContext(), android.R.style.Theme_Translucent_NoTitleBar);
            dialog.setContentView(R.layout.popup_add_department_layout);
            dialog.setCanceledOnTouchOutside(true);
            dialog.show();
            View dialogRootView = dialog.findViewById(R.id.IdDepartmentsPopup); // Replace with the actual ID of your root view
            dialogRootView.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    // Consume the touch event to prevent it from reaching the underlying views
                    return true;
                }
            });
            TextView dialogCloseTextVeiw = dialog.findViewById(R.id.dlg_TVClose);

            dialogCloseTextVeiw.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    DepartmentDialogClose();
                }
            });

            // Department Name get from User and store
            EditText Department_Name = dialog.findViewById(R.id.popup_department_Name);
            Button saveDepartmentName = dialog.findViewById(R.id.saveDepartmentName);

            saveDepartmentName.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // Get the department name from the input field
                    String departmentName = Department_Name.getText().toString().trim();

                    // Check if the department name is empty
                    if (departmentName.isEmpty()) {
                        // Display an error message
                        Toast.makeText(getContext(), "Department name cannot be empty", Toast.LENGTH_SHORT).show();
                    } else {
                        // If the department name is not empty, proceed to save it
                        Department department = new Department();
                        department.setName(departmentName);

                        DatabaseReference departmentRef = database.getReference().child("Department");
                        // Use push() to generate a unique ID and set the department under that ID
                        DatabaseReference newDepartmentRef = departmentRef.push();
                        department.setId(newDepartmentRef.getKey());
                        // Set the department data
                        newDepartmentRef.setValue(department);
                        Toast.makeText(getContext(), "Department added successfully", Toast.LENGTH_SHORT).show();
                        DepartmentDialogClose();
                    }
                }
            });
        } catch (Exception exception) {
            Toast.makeText(getContext(), exception.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void DepartmentDialogClose() {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
    }
}