package com.example.myapplication;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.myapplication.Model.Users;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;


public class ProfileFragment extends Fragment {
    private FirebaseAuth mAuth;
    private FirebaseDatabase database;
    private DatabaseReference reference;
    private ProgressDialog progressDialog;
    private Users currentUser;

    private TextView nameTextView, phoneTextView, emailTextView, profilDepartmentTextView, profileRoleNameTextView;
    private ImageView profileImageView;
    private EditText editTextPassword;
    Button saveDetailsButton;

    public ProfileFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        try{
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        initializeViews(view);
        setClickListeners();
        return view;
        }catch (Exception exception){
            Toast.makeText(getContext(), exception.getMessage(), Toast.LENGTH_LONG).show();
        }
        return null;
    }

    private void initializeViews(View view) {
        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        progressDialog = new ProgressDialog(requireContext());

        nameTextView = view.findViewById(R.id.Name);
        phoneTextView = view.findViewById(R.id.phoneNo);
        emailTextView = view.findViewById(R.id.Email);
        profilDepartmentTextView = view.findViewById(R.id.profil_Department);
        profileRoleNameTextView = view.findViewById(R.id.profile_RoleName);
        profileImageView = view.findViewById(R.id.profilePicture);
        editTextPassword = view.findViewById(R.id.Profil_password);
        saveDetailsButton = view.findViewById(R.id.Save);
    }

    private void setClickListeners() {
        try {
            profileImageView.setOnClickListener(v -> ImagePicker.with(requireActivity())
                    .crop()
                    .start());

            DatabaseReference userReference = database.getReference().child("Users").child(mAuth.getUid());
            userReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    try {
                        currentUser = snapshot.getValue(Users.class);
                        updateUI();
                    } catch (Exception exception) {
                        Toast.makeText(requireContext(), exception.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });

            reference = FirebaseDatabase.getInstance().getReference();
            reference.keepSynced(true);
            saveDetailsButton.setOnClickListener(v -> saveDetails());
        }catch (Exception exception){
            Toast.makeText(getContext(), "s"+exception.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void updateUI() {
        if (currentUser != null) {
            nameTextView.setText(currentUser.getName());
            String phoneNumber = currentUser.getPhoneNumber();
            phoneTextView.setText(phoneNumber != null ? phoneNumber : "");
            emailTextView.setText(currentUser.getEmail());
            editTextPassword.setText(currentUser.getPassword());
            profilDepartmentTextView.setText(currentUser.getDepartment().getName());
            profileRoleNameTextView.setText(currentUser.getRoleName());
            Picasso.get().load(currentUser.getImageUri())
                    .placeholder(requireContext().getResources().getDrawable(R.drawable.ic_baseline_account_circle_24))
                    .error(requireContext().getResources().getDrawable(R.drawable.ic_baseline_account_circle_24))
                    .into(profileImageView);
        }
    }

    private void saveDetails() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String newPassword = editTextPassword.getText().toString();

        AuthCredential credential = EmailAuthProvider.getCredential(user.getEmail(), currentUser.getPassword());
        user.reauthenticate(credential)
                .addOnCompleteListener(reauthTask -> {
                    if (reauthTask.isSuccessful()) {
                        user.updatePassword(newPassword)
                                .addOnCompleteListener(passwordUpdateTask -> {
                                    if (passwordUpdateTask.isSuccessful()) {
                                        currentUser.setPassword(newPassword);
                                        currentUser.setPhoneNumber(phoneTextView.getText().toString());
                                        database.getReference().child("Users").child(mAuth.getUid()).setValue(currentUser);
                                        Toast.makeText(requireContext(), "Password updated successfully", Toast.LENGTH_LONG).show();
                                    } else {
                                        Toast.makeText(requireContext(), "Password update failed: " + passwordUpdateTask.getException().getMessage(), Toast.LENGTH_LONG).show();
                                    }
                                });
                    } else {
                        Toast.makeText(requireContext(), "Reauthentication failed: " + reauthTask.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            Uri uri = data.getData();
            profileImageView.setImageURI(uri);
            progressDialog.show();
            StorageReference imageFolder = FirebaseStorage.getInstance().getReference().child("ImagesFolder");
            StorageReference imageName = imageFolder.child("image" + uri.getLastPathSegment());

            imageName.putFile(uri).addOnCompleteListener(task -> {
                imageName.getDownloadUrl().addOnSuccessListener(uri1 -> {
                    currentUser.setImageUri(uri1.toString());
                    database.getReference().child("Users").child(mAuth.getUid()).setValue(currentUser);
                    progressDialog.dismiss();
                });
            });
        } else {
            Toast.makeText(requireContext(), "Task Cancelled", Toast.LENGTH_SHORT).show();
        }
    }
}