package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.app.UiModeManager;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.Model.Users;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    DrawerLayout drawerLayout;
    Toolbar toolbar;
    NavigationView navigationView;
    FirebaseAuth mAuth;
    FirebaseDatabase database;

    Users CurrentUser;
    ImageView imageView;
    TextView textView;
    private MenuItem lastSelectedItem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            drawerLayout = findViewById(R.id.drawerLayout);
            toolbar = findViewById(R.id.toolBar);
            navigationView = findViewById(R.id.navigationView);
            View headerView = navigationView.getHeaderView(0);
            imageView = headerView.findViewById(R.id.navigationHeaderUserProfileImage);
            textView = headerView.findViewById(R.id.navigationHeaderUserName);

            //this is firebase database operations
            mAuth = FirebaseAuth.getInstance();
            database = FirebaseDatabase.getInstance();


            GetCurrentUser();
            setSupportActionBar(toolbar);

            ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar,
                    R.string.OpenDrawer, R.string.CloseDrawer);

            drawerLayout.addDrawerListener(toggle);
            toggle.syncState();
            MenuItem initialMenuItem = navigationView.getMenu().getItem(0); // Change 0 to the index of the item you want to be selected initially
            initialMenuItem.setChecked(true);
            lastSelectedItem = initialMenuItem;
            loadFragment(new HomeTaskFragment(), true);


            navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    int i = item.getItemId();
                    if (i == R.id.navigationItemTask) {
                        loadFragment(new HomeTaskFragment(), false);
                    } else if (i == R.id.navigationItemDepartment) {
                        loadFragment(new DepartmentsFragment(), false);
                    } else if (i == R.id.navigationItemTeachers) {
                        loadFragment(new TeachersFragment(), false);
                    } else if (i == R.id.navigationItemProfile) {
                        loadFragment(new ProfileFragment(), false);
                    } else if (i == R.id.navigationItemReport) {
                        loadFragment(new ReportFragment(), false);
                    } else {

                        FirebaseAuth.getInstance().signOut();
                        startActivity(new Intent(MainActivity.this, LoginActivity.class));
                        finish();
                    }
                    // Set the new item as checked
                    item.setChecked(true);

                    // Uncheck the last selected item
                    if (lastSelectedItem != null) {
                        lastSelectedItem.setChecked(false);
                    }

                    // Update the last selected item
                    lastSelectedItem = item;
                    drawerLayout.closeDrawer(GravityCompat.START);
                    return true;
                }
            });
        }catch (Exception exception){
            Toast.makeText(this, "" + exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.d("GaneshPawar",exception.getMessage());
         }
    }
    private void loadFragment(Fragment fragment,boolean flag){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        if(flag == true) {
            fragmentTransaction.add(R.id.container, fragment);
        }else {
            fragmentTransaction.replace(R.id.container, fragment);
        }
        fragmentTransaction.commit();
    }

    private  void  GetCurrentUser(){
        try {
            database.getReference().child("Users").child(Objects.requireNonNull(mAuth.getUid())).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    try{
                        CurrentUser = snapshot.getValue(Users.class);
                        textView.setText(CurrentUser.getName());
                        Picasso.get().load(CurrentUser.getImageUri())
                                .placeholder(MainActivity.this.getResources().getDrawable(R.drawable.ic_baseline_account_circle_24))
                                .error(MainActivity.this.getResources().getDrawable(R.drawable.ic_baseline_account_circle_24))
                                .into(imageView);
                        if(CurrentUser.getRoleName().equalsIgnoreCase("Teacher")){
                            MenuItem reportMenuItem = navigationView.getMenu().findItem(R.id.navigationItemReport);
                            reportMenuItem.setVisible(false);
                            reportMenuItem = navigationView.getMenu().findItem(R.id.navigationItemDepartment);
                            reportMenuItem.setVisible(false);
                            reportMenuItem = navigationView.getMenu().findItem(R.id.navigationItemTeachers);
                            reportMenuItem.setVisible(false);
                        }else if(CurrentUser.getRoleName().equalsIgnoreCase("HOD")){
                            MenuItem reportMenuItem = navigationView.getMenu().findItem(R.id.navigationItemDepartment);
                            reportMenuItem.setVisible(false);
                        }
                    }catch (Exception exception){
                        Toast.makeText(MainActivity.this, exception.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });
        }catch (Exception exception){
            Toast.makeText(MainActivity.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

}