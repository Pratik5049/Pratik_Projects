package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.example.myapplication.Model.Department;
import com.example.myapplication.Model.ReportExport;
import com.example.myapplication.Model.Task;
import com.example.myapplication.Model.Users;
import com.example.myapplication.Model.XlsMode;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import org.joda.time.DateTime;
import org.joda.time.Days;
import java.util.ArrayList;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import android.os.Environment;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.MultiAutoCompleteTextView;
import android.widget.Toast;

import android.provider.MediaStore;
public class ReportFragment extends Fragment implements ExportInterface {
    ArrayList<Task> taskList = new ArrayList<>();
    ArrayList<Department> departmentArrayList = new ArrayList<>();
    ArrayList<Users> UserArrayList = new ArrayList<>();
    private FirebaseDatabase database;
    private Button selectDepartmentDialog;
    private DatePicker startMonthYearDatePicker,endMonthYearDatePicker;
    private MultiAutoCompleteTextView userMultiAutoCompleteTextView;
    String[] departmentName;
    ArrayList<Integer> selectedDepartmentsIndices  = new ArrayList<>();
    ArrayList<String> departmentNameArrayList = new ArrayList<>();
    boolean[] selectedbool;
    CheckBox checkBox;
    FirebaseAuth mAuth;
    Users CurrentUser;
    public ReportFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        try {
            // Inflate the layout for this fragment
            View view = inflater.inflate(R.layout.fragment_report, container, false);
            mAuth = FirebaseAuth.getInstance();
            database = FirebaseDatabase.getInstance();

            // Initialize UI elements
            initializeUIElements(view);
            GetCurrentUser();
            GetAlltask();

            GetAllUsers();

            Button exportExcel = view.findViewById(R.id.ExportExcel);
            exportExcel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    generateReport();
                }
            });
            return view;
        }catch (Exception exception){
            Toast.makeText(getContext(), exception.getMessage(), Toast.LENGTH_SHORT).show();
        }
        return null;
    }
    private void generateReport() {
        try {
            // Dates
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date startDate = getSelectedDate(startMonthYearDatePicker);
            Date endDate = getSelectedDate(endMonthYearDatePicker);
            if(isValidDateRange(startDate,endDate)==false){
                Toast.makeText(getContext(), "End date not earlier than the start date", Toast.LENGTH_SHORT).show();
                return;
            }

            ArrayList<Department> selectedDepartments = new ArrayList<>();
            for (int j = 0; j < selectedbool.length; j++) {
                if (selectedbool[j]) {
                    // Find the corresponding Department object based on the selected department name
                    String selectedDepartmentName = departmentName[j];
                    for (Department department : departmentArrayList) {
                        if (department.getName().equals(selectedDepartmentName)) {
                            selectedDepartments.add(department);
                            break;
                        }
                    }
                }
            }

            HashMap<String, String> otherValue = new HashMap<>();

            //Export file
            List<XlsMode> xlsModeList = new ArrayList<>();
            List<ReportExport> xlsModeListReportExport = new ArrayList<>();
            String departmentName = "";
            int i=1;
            for (Department department:selectedDepartments)
            {
                Toast.makeText(getContext(), ""+department, Toast.LENGTH_SHORT).show();
                for (Users user : UserArrayList) {
                    if(department.getName().equalsIgnoreCase(user.getDepartment().getName())== true)
                    {
                        for (Task task : taskList) {
                            if (task.getUsers() != null && isTaskWithinDateRange(task, startDate, endDate)) {
                                if (task.getUsers().getId().equals(user.getId())) {
                                if(checkBox.isChecked() == true){
                                    if (task.getStartDate() != null && task.getEndDate() != null && task.getPerformedStartDate() != null && task.getPerformedEndDate() != null) {
                                        double consistency = calculateConsistency(dateFormat.format(task.getStartDate()), dateFormat.format(task.getEndDate()), dateFormat.format(task.getPerformedStartDate()),dateFormat.format(task.getPerformedEndDate()));
                                        xlsModeListReportExport.add(new ReportExport("" + i++, user.getDepartment().getName(), task.getName(), user.getName(), dateFormat.format(task.getStartDate()), dateFormat.format(task.getEndDate()), dateFormat.format(task.getPerformedStartDate()), dateFormat.format(task.getPerformedEndDate()), "" + consistency));
                                    }
                                }else{
                                    if (task.getStartDate() != null && task.getEndDate() != null) {
                                        if (task.getFileUrl() == null) {
                                            xlsModeList.add(new XlsMode("" + i++, user.getDepartment().getName(), user.getName(), task.getName(), dateFormat.format(task.getStartDate()), dateFormat.format(task.getEndDate()), task.getStatus(), "-"));
                                        } else{
                                            xlsModeList.add(new XlsMode("" + i++, user.getDepartment().getName(), user.getName(), task.getName(), dateFormat.format(task.getStartDate()), dateFormat.format(task.getEndDate()), task.getStatus(), task.getFileUrl().toString()));
                                        }
                                    }
                                }
                                }
                            }
                        }
                    }
                }
                departmentName += department.getName()+ ",";
            }

            if(xlsModeListReportExport.size() == 0 && xlsModeList.size() == 0){
                Toast.makeText(getContext(), "For export report, there must be at least one record", Toast.LENGTH_SHORT).show();
                return;
            }

            otherValue.put("Deparments", departmentName.toString());
            otherValue.put("Start Date", dateFormat.format(startDate));
            otherValue.put("End Date", dateFormat.format(endDate));
            Gson gson = new Gson();
            if(checkBox.isChecked() == true){
                var jsonArray = gson.toJsonTree(xlsModeListReportExport).getAsJsonArray();
                String[] titles = new String[]{"Sr.no","Department","Task Name", "Teacher Name","Actual Start Date", " Actual End Date","Performed Start Date","Performed End Date", "Consistency"};
                String[] indexName = new String[]{"Index","DepartmentName", "TaskName", "AssignUserName", "PlanedStartDate", "PlanedEndDate","PerformedStartDate","PerformedEndDate","Consistency"};
                var file = generateXlsFile(getActivity(), titles, indexName, jsonArray, otherValue, "Task Record", "ConsistencyReport", 1);
                // Save the generated Excel file to external storage
                saveToExternalStorage(file);
                Toast.makeText(getContext(), "ConsistencyReport generated successfully", Toast.LENGTH_SHORT).show();
            }
            else {
                var jsonArray = gson.toJsonTree(xlsModeList).getAsJsonArray();
                String[] titles = new String[]{"Sr.no","Department", "Teacher Name", "Task Name", "Start Date", "End Date","Status", "Uploaded File URL"};
                String[] indexName = new String[]{"Index","Department", "UserName", "TaskName", "StartDate", "EndDate","Status","FileUrl"};
                var file = generateXlsFile(getActivity(), titles, indexName, jsonArray, otherValue, "Task Record", "Report", 1);
                // Save the generated Excel file to external storage
                saveToExternalStorage(file);
            }


        }catch (Exception e){
            Toast.makeText(getContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    public static double calculateConsistency(String plannedStartDate, String plannedEndDate, String performedStartDate, String performedEndDate) {
        DateTime plannedStart = DateTime.parse(plannedStartDate);
        DateTime plannedEnd = DateTime.parse(plannedEndDate);
        DateTime performedStart = DateTime.parse(performedStartDate);
        DateTime performedEnd = DateTime.parse(performedEndDate);

        int totalDaysInPlannedInterval = Days.daysBetween(plannedStart, plannedEnd).getDays();
        int totalDaysInPerformedInterval = Days.daysBetween(performedStart, performedEnd).getDays();
        int overdueDays = Days.daysBetween(performedStart, plannedStart).getDays();
        int delayDays = Days.daysBetween(plannedEnd, performedEnd).getDays();

        if (totalDaysInPlannedInterval == 0) {
            return 0;
        }

        double consistency = 1 - ((double) (overdueDays + delayDays)) / totalDaysInPlannedInterval;
        consistency = Math.min(consistency * 100, 100);
        return consistency;
    }


    private boolean isValidDateRange(Date startDate, Date endDate) {
        if (startDate != null && endDate != null) {
            // Check if the start date is not in the future
            if (startDate.after(new Date())) {
                Toast.makeText(getContext(), "Invalid Start Date ", Toast.LENGTH_SHORT).show();
                return false;
            }
            if (endDate.after(new Date())) {
                Toast.makeText(getContext(), "Invalid End Date must be greater than start date", Toast.LENGTH_SHORT).show();
                return false;
            }

            // Check if the end date is the same or not earlier than the start date
            return !endDate.before(startDate);
        }

        return true;
    }
    private void initializeUIElements(View view) {
        selectDepartmentDialog = view.findViewById(R.id.selectDepartmentDialog);
        checkBox = view.findViewById(R.id.checkBox);
        selectDepartmentDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDepartmentSelectionDialog();
            }
        });
        startMonthYearDatePicker = view.findViewById(R.id.startMonthYearDatePicker);
        endMonthYearDatePicker = view.findViewById(R.id.endMonthYearDatePicker);
    }
    private Date getSelectedDate(DatePicker datePicker) {
        int year = datePicker.getYear();
        int month = datePicker.getMonth();
        int day = datePicker.getDayOfMonth();
        return new Date(year - 1900, month, day);
    }
    private boolean isTaskWithinDateRange(Task task, Date startDate, Date endDate) {
        return (startDate.before(task.getStartDate()) && task.getStartDate().before(endDate))
                || (startDate.before(task.getEndDate()) && task.getEndDate().before(endDate));
    }

    private  void  GetCurrentUser(){
        try {
            database.getReference().child("Users").child(Objects.requireNonNull(mAuth.getUid())).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    try{
                        CurrentUser = snapshot.getValue(Users.class);
                        fetchDepartments();
                    }catch (Exception exception){
                        Toast.makeText(getContext(), exception.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });
        }catch (Exception exception){
            Toast.makeText(getContext(), exception.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    private void showDepartmentSelectionDialog(){
        selectedbool = new boolean[departmentNameArrayList.size()];
        departmentName = departmentNameArrayList.toArray(new String[0]);
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Department / Section");
        builder.setCancelable(false);
        builder.setMultiChoiceItems(departmentName, selectedbool, new DialogInterface.OnMultiChoiceClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i, boolean b) {
                if (b) {
                    selectedDepartmentsIndices .add(i);
                    Collections.sort(selectedDepartmentsIndices );
                } else {
                    selectedDepartmentsIndices .remove(i);
                }
            }
        });
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                StringBuilder stringBuilder = new StringBuilder();
                for (int j = 0; j < selectedDepartmentsIndices .size(); j++) {
                    stringBuilder.append(departmentName[selectedDepartmentsIndices .get(j)]);
                    if (j != selectedDepartmentsIndices .size() - 1) {
                        stringBuilder.append(", ");
                    }
                }
            }
        });
        builder.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });

        builder.setNeutralButton("Clear all", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                for (int j = 0; j < selectedbool.length; j++) {
                    selectedbool[j] = false;
                    selectedDepartmentsIndices .clear();
                }
            }
        });
        builder.show();
    }
    private void GetAlltask( ){
        try{
            database.getReference().child("Task").addValueEventListener(new ValueEventListener() {
                @SuppressLint("NotifyDataSetChanged")
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    try{
                        for (DataSnapshot data : snapshot.getChildren()) {
                            Task task = data.getValue(Task.class);
                            taskList.add(task);
                        }
                    }catch (Exception exception){
                        Toast.makeText(getContext(), exception.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });
        }catch (Exception exception){
            Toast.makeText(getContext(), exception.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    private void fetchDepartments() {
        database.getReference().child("Department").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                departmentArrayList.clear();
                departmentNameArrayList.clear();
                if(CurrentUser.getRoleName().equalsIgnoreCase("HOD")){
                    departmentArrayList.add(CurrentUser.getDepartment());
                    departmentNameArrayList.add(CurrentUser.getDepartment().getName());
                }else {
                for (DataSnapshot data : snapshot.getChildren()) {
                    Department department = data.getValue(Department.class);
                    if (department != null) {
                        departmentArrayList.add(department);
                        departmentNameArrayList.add(department.getName());
                    }
                }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle errors here
            }
        });
    }
    private void GetAllUsers( ){
        try{
            database.getReference().child("Users").addValueEventListener(new ValueEventListener() {
                @SuppressLint("NotifyDataSetChanged")
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    try{
                        UserArrayList.clear();
                        for (DataSnapshot data : snapshot.getChildren()) {
                            Users users = data.getValue(Users.class);
                            UserArrayList.add(users);
                        }
                    }catch (Exception exception){
                        Toast.makeText(getContext(), exception.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });
        }catch (Exception exception){
            Toast.makeText(getContext(), exception.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    // Save to external storage using MediaStore
    private void saveToExternalStorage(File file) {
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, file.getName());
            contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

            Uri contentUri = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL);
            Uri uri = requireContext().getContentResolver().insert(contentUri, contentValues);

            try (OutputStream outputStream = requireContext().getContentResolver().openOutputStream(uri)) {
                if (outputStream != null) {
                    // Copy the file
                    copyFile(file, outputStream);
                    Toast.makeText(requireContext(), "Report file downloaded successfully", Toast.LENGTH_SHORT).show();
                    openFile(uri);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    // Copy file using standard Java libraries
    private void copyFile(File sourceFile, OutputStream outputStream) throws IOException {
        try (InputStream in = new FileInputStream(sourceFile)) {
            byte[] buffer = new byte[1024];
            int length;

            while ((length = in.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }
        }
    }
    private void openFile(Uri fileUri) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(fileUri, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(requireContext(), "No application found to open the file", Toast.LENGTH_SHORT).show();
        }
    }

}