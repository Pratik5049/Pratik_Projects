package com.example.myapplication;



import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class LoginActivity extends AppCompatActivity implements GoogleApiClient.OnConnectionFailedListener {
    private FirebaseAuth mAuth;
    FirebaseDatabase database;
    EditText Email, Password;



    CheckBox showPasswordCheckBox;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            super.onCreate(savedInstanceState);
            try {
                FirebaseDatabase.getInstance().setPersistenceEnabled(true);
            } catch (Exception e) {}
            setContentView(R.layout.activity_login);
            //this is firebase database operations
            mAuth = FirebaseAuth.getInstance();

            // Check user is login
            CheckUser();

            showPasswordCheckBox = findViewById(R.id.loginPage_showPassword_checkBox);

            //all id
            Email = findViewById(R.id.editTextEmail);
            Password = findViewById(R.id.editTextPassword);

            Button loginBtn = findViewById(R.id.cirLoginButton);

            showPasswordCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        // Show password
                        Password.setTransformationMethod(null);
                    } else {
                        // Hide password
                        Password.setTransformationMethod(new PasswordTransformationMethod());
                    }
                }
            });

            // User login with email and password
            loginBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // check Authentication with Email and password
                    mAuth.signInWithEmailAndPassword(Email.getText().toString(), Password.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            try {
                                if (task.isSuccessful()) {
                                    CheckUser();
                                } else {
                                    Toast.makeText(LoginActivity.this, "" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }catch (Exception exception){
                                Toast.makeText(LoginActivity.this, ""+exception.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            });

        } catch (Exception exception) {
            Toast.makeText(this, "" + exception.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Toast.makeText(this, "onConnectionFailed: " + connectionResult, Toast.LENGTH_SHORT).show();
    }

    // Check user is login
    private void CheckUser() {
        if (mAuth.getCurrentUser() != null) {
            startActivity(new Intent(LoginActivity.this, MainActivity.class));
            finish();
        }
    }



}