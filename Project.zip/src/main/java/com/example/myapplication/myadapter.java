package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.myapplication.Model.Task;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Random;


public class myadapter extends RecyclerView.Adapter<myadapter.myviewholder>
{
    public Context context;
    private List<Task> dataholder;


    public myadapter(Context context, List<Task> dataholder) {
        this.dataholder = dataholder;
        this.context = context;
    }

    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.text_row_item,parent,false);
        return new myviewholder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull myviewholder holder, int position)
    {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        // Format the startDate and endDate as strings
        String startDateString = dateFormat.format(dataholder.get(position).getStartDate());
        String endDateString = dateFormat.format(dataholder.get(position).getEndDate());

        // Set the formatted date strings in the TextViews
        holder.TaskEndDate.setText("End Date:- "+endDateString);
        holder.TaskStartDate.setText("Start Date:- "+startDateString);
        holder.TaskName.setText("Title:- "+dataholder.get(position).getName());
        holder.TaskNote.setText("Note:- "+dataholder.get(position).getNote());
        holder.TaskStatus.setText("Status:- "+dataholder.get(position).getStatus());
    }

    @Override
    public int getItemCount() {
        return dataholder.size();
    }

    class myviewholder extends RecyclerView.ViewHolder
    {
        TextView TaskName,TaskNote,TaskEndDate,TaskStartDate,TaskStatus;
        LinearLayout box;
        public myviewholder(@NonNull View itemView)
        {
            super(itemView);
            TaskName=(TextView)itemView.findViewById(R.id.TaskName);
            TaskNote=(TextView)itemView.findViewById(R.id.TaskNote);
            TaskEndDate=(TextView)itemView.findViewById(R.id.TaskEndDate);
            TaskStartDate=(TextView)itemView.findViewById(R.id.TaskStartDate);
            TaskStatus=(TextView)itemView.findViewById(R.id.TaskStatus);
            
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                    Intent intent = new Intent(context, TaskAllInformation.class);
                    intent.putExtra("TaskID",dataholder.get(getAdapterPosition()).getId());
                    context.startActivity(intent);
                    }catch (Exception exception){
                        Toast.makeText(context, exception.getMessage().toString(), Toast.LENGTH_SHORT).show();
                    }
                }
            });

        }
    }
    public  void updateList(List<Task> list){
        dataholder = list;
        notifyDataSetChanged();
    }

    public int getRandomColor() {
        Random random = new Random();
        // Generate random RGB values
        int r = random.nextInt(256);
        int g = random.nextInt(256);
        int b = random.nextInt(256);
        // Create a color with random RGB values
        return Color.rgb(r, g, b);
    }


}

