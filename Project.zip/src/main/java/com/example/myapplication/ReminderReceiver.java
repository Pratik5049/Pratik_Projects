package com.example.myapplication;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;
public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "ReminderChannel";
    private static final int NOTIFICATION_ID = 1;
    @Override
    public void onReceive(Context context, Intent intent) {
        String task = intent.getStringExtra("task");

        // Handle the reminder, for example, show a notification or display a Toast
      //  Toast.makeText(context, "Reminder: " + task, Toast.LENGTH_SHORT).show();
        showNotification(context, "Reminder: " + task);
    }
    private void showNotification(Context context, String message) {
        try {
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

            // Create a notification channel (required for Android Oreo and above)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Reminder Channel", NotificationManager.IMPORTANCE_DEFAULT);
                notificationManager.createNotificationChannel(channel);
            }

            // Create an intent to open the ReminderActivity
            Intent openAppIntent = new Intent(context, MainActivity.class);
            PendingIntent pendingIntent ;

            // Use FLAG_IMMUTABLE for PendingIntent
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                pendingIntent = PendingIntent.getActivity(context, 0, openAppIntent, PendingIntent.FLAG_IMMUTABLE);
            } else {
                pendingIntent = PendingIntent.getActivity(context, 0, openAppIntent, PendingIntent.FLAG_MUTABLE);
            }

            // Create a notification
            NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle("Reminder")
                    .setContentText(message)
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setContentIntent(pendingIntent)  // Set the intent to be triggered when the notification is clicked
                    .setAutoCancel(true);

            // Show the notification
            notificationManager.notify(NOTIFICATION_ID, builder.build());
        }catch (Exception exception){
            Log.d("Ganesh", exception.getMessage());
        }
    }

}

