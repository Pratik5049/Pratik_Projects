package com.example.myapplication;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.Model.Task;
import com.example.myapplication.Model.Users;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class AssingUserInfoActivity extends AppCompatActivity {
    FirebaseDatabase database;
    TextView userName,userEmail,userDepartment,UserPhone;
    ImageView userProfile;
    RecyclerView recyclerViewTask;
    ArrayList<Task> recyclerViewList = new ArrayList<>();
    Users assingUser;
    myadapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assing_user_info);
        String UserID = getIntent().getExtras().getString("assignUserID");
        initializeUI();
        setupRecyclerView();
        try {
            database = FirebaseDatabase.getInstance();
            database.getReference().child("Users").child(UserID).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    try{
                        assingUser = snapshot.getValue(Users.class);
                        userName.setText(assingUser.getName());
                        userEmail.setText(assingUser.getEmail());
                        userDepartment.setText(assingUser.getDepartment().getName());
                        if(assingUser.getPhoneNumber() != null) {
                            UserPhone.setText(assingUser.getPhoneNumber());
                        }
                        Picasso.get().load(assingUser.getImageUri())
                                .placeholder(AssingUserInfoActivity.this.getResources().getDrawable(R.drawable.ic_baseline_account_circle_24))
                                .error(AssingUserInfoActivity.this.getResources().getDrawable(R.drawable.ic_baseline_account_circle_24))
                                .into(userProfile);
                    }catch (Exception exception){
                        Toast.makeText(AssingUserInfoActivity.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });

            try{
                database.getReference().child("Task").addValueEventListener(new ValueEventListener() {
                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        try{
                            recyclerViewList.clear();
                            for (DataSnapshot data : snapshot.getChildren()) {
                                Task task = data.getValue(Task.class);
                                if(task.getUsers() != null){
                                    if(task.getUsers().getId().equals(assingUser.getId())){
                                        recyclerViewList.add(task);
                                    }
                                }
                            }
                            adapter.notifyDataSetChanged();
                        }catch (Exception exception){
                            Toast.makeText(AssingUserInfoActivity.this, exception.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
            }catch (Exception exception){
                Toast.makeText(this, exception.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }catch (Exception exception){
            Toast.makeText(this, exception.getMessage(), Toast.LENGTH_SHORT).show();
        }

    }
    private void setupRecyclerView() {
        recyclerViewTask.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        adapter = new myadapter(AssingUserInfoActivity.this, recyclerViewList);
        recyclerViewTask.setAdapter(adapter);
    }
    private void initializeUI() {
        userName = findViewById(R.id.assing_user_name);
        userEmail = findViewById(R.id.assing_user_email);
        userDepartment = findViewById(R.id.assing_user_department);
        UserPhone = findViewById(R.id.assing_user_phone);
        userProfile = findViewById(R.id.assing_user_profileImage);
        recyclerViewTask = findViewById(R.id.assing_userTask_recyclerView);
    }
}