package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.Model.Users;
import com.squareup.picasso.Picasso;

import java.util.List;

public class TeachersRecyclerApapter extends RecyclerView.Adapter<TeachersRecyclerApapter.myviewholder> {
    public Context context;
    private final List<Users> dataholder;

    public  TeachersRecyclerApapter(Context context,List<Users> dataholder){
        this.dataholder = dataholder;
        this.context = context;
    }

    @NonNull
    @Override
    public TeachersRecyclerApapter.myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.techers_row_item,parent,false);
        return new TeachersRecyclerApapter.myviewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myviewholder holder, int position) {
        holder.UserName.setText(dataholder.get(position).getName());
        holder.UserEmail.setText(dataholder.get(position).getEmail());
        Picasso.get().load(dataholder.get(position).getImageUri()).
                placeholder(context.getResources().getDrawable(R.drawable.ic_baseline_account_circle_24))
                .error(context.getResources().getDrawable(R.drawable.ic_baseline_account_circle_24))
                .into(holder.imageView);

    }


    @Override
    public int getItemCount() {
        return dataholder.size();
    }

    class myviewholder  extends RecyclerView.ViewHolder
    {
        TextView UserName,UserEmail;
        ImageView imageView;
        public myviewholder(@NonNull View itemView)
        {
            super(itemView);
            UserName=(TextView)itemView.findViewById(R.id.recycler_Username);
            UserEmail=(TextView)itemView.findViewById(R.id.recycler_UserEmail);
            imageView=(ImageView)itemView.findViewById(R.id.imageView);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        Intent intent = new Intent(context, AssingUserInfoActivity.class);
                        intent.putExtra("assignUserID",dataholder.get(getAdapterPosition()).getId());
                        context.startActivity(intent);
                    }catch (Exception exception) {
                        Toast.makeText(context, exception.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });

        }
    }
}
