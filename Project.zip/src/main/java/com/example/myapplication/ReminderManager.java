package com.example.myapplication;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.SystemClock;
import android.widget.Toast;
import java.util.Calendar;

public class ReminderManager {

    private static final int JOB_ID = 1000; // Unique job ID

    public static void setReminder(Context context, Class<?> receiverClass, String task, long taskDateInMillis) {
        try {
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(context, receiverClass);
            intent.putExtra("task", task);

            PendingIntent pendingIntent;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                // Use JobIntentService for Android 8.0 and above
                pendingIntent = PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_IMMUTABLE);
                context.startService(intent);
            } else {
                // Use BroadcastReceiver for versions below Android 8.0
                pendingIntent = PendingIntent.getService(context, 0, intent, PendingIntent.FLAG_IMMUTABLE);
                intent.setPackage(context.getPackageName()); // Required for implicit broadcasts
            }

            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(taskDateInMillis);

            // Set an alarm with AlarmManager
            alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);

            // For testing purposes, you can use the following line to set an alarm that fires after a specified time (e.g., 10 seconds).
             //alarmManager.set(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 10000, pendingIntent);
        } catch (Exception exception) {
            Toast.makeText(context, exception.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
