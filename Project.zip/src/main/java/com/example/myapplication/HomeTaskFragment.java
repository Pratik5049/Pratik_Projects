package com.example.myapplication;

import android.content.Intent;

import java.util.Calendar;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.Model.Department;
import com.example.myapplication.Model.Task;
import com.example.myapplication.Model.Users;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Objects;

public class HomeTaskFragment extends Fragment {
    ArrayList<Task> recyclerViewList = new ArrayList<>();
    RecyclerView recyclerView;
    myadapter adapter;
    DatabaseReference reference;
    private FirebaseAuth mAuth;
    private FirebaseDatabase database;
    FloatingActionButton AddTaskButton;
    Users CurrentUser;
    Dialog dialog;
    private TextView selectedFileTextView;

    private static final int REQUEST_FILE_PICKER = 1;
    private Uri selectedFileUri;
    ArrayList<Users> UsersList = new ArrayList<>();
    boolean[] selectedbool;
    String[] username1;
    ArrayList<Integer> Selectedlist = new ArrayList<>();
    ArrayList<Department> departmentArrayList = new ArrayList<>();
    ArrayList<String> departmentNameArrayList = new ArrayList<>();
    public HomeTaskFragment() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_home_task, container, false);
        initializeViews(view);
        setupRecyclerView();
        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        reference = FirebaseDatabase.getInstance().getReference().child("Task");
        reference.keepSynced(true);
        GetCurrentUser();
        GetAllUser();
        // Fetch department data from Firebase
        fetchDepartments();

        AddTaskButton.setOnClickListener(view1 -> openAddTaskDialog());
        return view;
    }
    private void initializeViews(View view) {
        recyclerView = view.findViewById(R.id.task_recview);
        AddTaskButton = view.findViewById(R.id.floatingActionButtonAddTask);
    }
    private void setupRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        adapter = new myadapter(getContext(), recyclerViewList);
        recyclerView.setAdapter(adapter);
    }
    private void GetAlltask( ){
        try{
            database.getReference().child("Task").addValueEventListener(new ValueEventListener() {
                @SuppressLint("NotifyDataSetChanged")
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    try{
                        recyclerViewList.clear();
                        for (DataSnapshot data : snapshot.getChildren()) {
                            Task task = data.getValue(Task.class);
                            filterTasksByRole(task);
                        }
                        adapter.notifyDataSetChanged();
                    }catch (Exception exception){
                        Toast.makeText(getContext(), exception.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });
        }catch (Exception exception){
            Toast.makeText(getContext(), exception.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    private void filterTasksByRole(Task task) {
        if (CurrentUser.getRoleName().equals("HOD")) {
            AddTaskButton.setVisibility(View.VISIBLE);
            filterTasksForHOD(task);
        } else if (CurrentUser.getRoleName().equals("Teacher")) {
            AddTaskButton.setVisibility(View.GONE);
            filterTasksForTeacher(task);
        } else {
            AddTaskButton.setVisibility(View.VISIBLE);
            recyclerViewList.add(task);
        }
    }
    private void filterTasksForHOD(Task task) {
        if (task.getDepartment() != null) {
            for (Department taskDepartment : task.getDepartment()) {
                if (CurrentUser.getDepartment().getId().contains(taskDepartment.getId())) {
                    recyclerViewList.add(task);
                }
            }
        }
    }
    private void filterTasksForTeacher(Task task) {
        if (task.getUsers() != null && task.getUsers().getId().equals(CurrentUser.getId())) {
            recyclerViewList.add(task);
            long currentMillis = System.currentTimeMillis();
            long taskStartMillis = task.getStartDate().getTime(); // Assuming getStartDate() returns time in milliseconds

           // Calculate the time difference in milliseconds
            long timeDifferenceMillis = taskStartMillis - currentMillis - 86400000;
             //long timeDifferenceMillis = taskStartMillis - currentMillis ;
            if (timeDifferenceMillis > 0) {
                ReminderManager.setReminder(getContext(), ReminderReceiver.class, task.getName(), taskStartMillis);
                // Toast.makeText(getContext(), "Reminder set", Toast.LENGTH_SHORT).show();
            }

        }
    }
    private  void  GetCurrentUser(){
        try {
            database = FirebaseDatabase.getInstance();
            database.getReference().child("Users").child(Objects.requireNonNull(mAuth.getUid())).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    try{
                        CurrentUser = snapshot.getValue(Users.class);
                        GetAlltask();
                    }catch (Exception exception){
                        Toast.makeText(getContext(), exception.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });
        }catch (Exception exception){
            Toast.makeText(getContext(), exception.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void GetAllUser(){
        try {
            database = FirebaseDatabase.getInstance();
            database.getReference().child("Users").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    try{
                        UsersList.clear();
                        for (DataSnapshot data : snapshot.getChildren()) {
                            Users users = data.getValue(Users.class);
                            UsersList.add(users);
                        }
                    }catch (Exception exception){
                        Toast.makeText(getContext(), exception.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });
        }catch (Exception exception){
            Toast.makeText(getContext(), exception.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    private void openAddTaskDialog() {
        try {
            dialog = new Dialog(getContext(), android.R.style.Theme_Translucent_NoTitleBar);
            dialog.setContentView(R.layout.popup_add_task);
            dialog.setCanceledOnTouchOutside(false);
            dialog.show();
            View dialogRootView = dialog.findViewById(R.id.IdAddTaskPopup); // Replace with the actual ID of your root view
            dialogRootView.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    // Consume the touch event to prevent it from reaching the underlying views
                    return true;
                }
            });
            TextView dialogCloseTextVeiw = dialog.findViewById(R.id.dlg_TVClose);
            dialogCloseTextVeiw.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    TaskDialogClose();
                }
            });
            EditText taskName = dialog.findViewById(R.id.addTaskPopup_taskName);
            EditText note = dialog.findViewById(R.id.addTaskPopup_Note);

            Button SelectDepartment = dialog.findViewById(R.id.popup_add_task_SelectDepartment);
            selectedbool = new boolean[departmentNameArrayList.size()];
            username1 = departmentNameArrayList.toArray(new String[0]);
            SelectDepartment.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    builder.setTitle("Department / Section");
                    builder.setCancelable(false);
                    builder.setMultiChoiceItems(username1, selectedbool, new DialogInterface.OnMultiChoiceClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i, boolean b) {
                            if (b) {
                                Selectedlist.add(i);
                                Collections.sort(Selectedlist);
                            } else {
                                Selectedlist.remove(i);
                            }
                        }
                    });
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            StringBuilder stringBuilder = new StringBuilder();
                            for (int j = 0; j < Selectedlist.size(); j++) {
                                stringBuilder.append(username1[Selectedlist.get(j)]);
                                if (j != Selectedlist.size() - 1) {
                                    stringBuilder.append(", ");
                                }
                            }
                            Toast.makeText(getContext(), stringBuilder.toString(), Toast.LENGTH_SHORT).show();
                        }
                    });
                    builder.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                        }
                    });

                    builder.setNeutralButton("Clear all", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            for (int j = 0; j < selectedbool.length; j++) {
                                selectedbool[j] = false;
                                Selectedlist.clear();
                            }
                        }
                    });
                    builder.show();
                }
            });
            // Assing
            if(CurrentUser.getRoleName().equals("HOD")){
                CardView cardView =dialog.findViewById(R.id.popup_add_task_cardView_assing);
                cardView.setVisibility(View.VISIBLE);
            }
            ArrayList<String> DepartmentTeacherList = new ArrayList<>();
            for (Users users: UsersList) {
                if(users.getDepartment().getName().equalsIgnoreCase(CurrentUser.getDepartment().getName())){
                    DepartmentTeacherList.add(users.getName());
                }
            }
            // Toast.makeText(getContext(), ""+DepartmentTeacherList.size(), Toast.LENGTH_SHORT).show();
            ArrayAdapter<String> adapter1 = new ArrayAdapter<>(getContext(), android.R.layout.select_dialog_item,DepartmentTeacherList );
            Spinner AssingCompleteTextView = dialog.findViewById(R.id.popup_add_task_assing);
            AssingCompleteTextView.setAdapter(adapter1);

            //Start and End date
            EditText startDate = dialog.findViewById(R.id.startDateEditText);
            startDate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    showDatePickerDialog(startDate);
                }
            });
            EditText endDate = dialog.findViewById(R.id.endDateEditText);
            endDate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    showDatePickerDialog(endDate);
                }
            });

            //File get
            selectedFileTextView = dialog.findViewById(R.id.selectedFileTextView);
            Button button = dialog.findViewById(R.id.selectFileButton);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openFilePicker();
                }
            });
            //Department
            if (CurrentUser.getRoleName().equals("HOD") || CurrentUser.getRoleName().equals("Teacher")) {
                CardView cardView = dialog.findViewById(R.id.popup_add_task_cardView_department);
                cardView.setVisibility(View.GONE);
            }
            //Description
            EditText description = dialog.findViewById(R.id.popup_add_task_Description);
            // Status
            EditText status = dialog.findViewById(R.id.popup_add_task_status);
            //Save task
            Button saveTask = dialog.findViewById(R.id.save_popupAddTask);
            saveTask.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        Task task = new Task();
                        // Get the values from the input fields
                        String taskNameStr = taskName.getText().toString().trim();
                        String noteStr = note.getText().toString().trim();
                        String startDateStr = startDate.getText().toString().trim();
                        String endDateStr = endDate.getText().toString().trim();
                        String statusStr = endDate.getText().toString().trim();

                        if (taskNameStr.isEmpty() || startDateStr.isEmpty() || endDateStr.isEmpty() || noteStr.isEmpty()|| statusStr.isEmpty()) {
                            Toast.makeText(getContext(), "Please fill in all required fields", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        task.setName(taskName.getText().toString());
                        task.setNote(note.getText().toString());
                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                        Date date = dateFormat.parse(startDate.getText().toString());
                        task.setStartDate(date);
                        date = dateFormat.parse(endDate.getText().toString());
                        task.setEndDate(date);
                        task.setDescription(description.getText().toString());
                        task.setStatus(status.getText().toString());
                        // Assing Teacher
                        if (CurrentUser.getRoleName().equals("HOD")) {
                            // Get the selected value from the spinner
                            String selectedValue = AssingCompleteTextView.getSelectedItem().toString();
                            // Initialize a selectedUser variable to null
                            Users selectedUser = null;
                            // Iterate through the UsersList to find the user with the selected value
                            for (Users user : UsersList) {
                                if (user.getName().equals(selectedValue)) { // Assuming you want to match by user name
                                    selectedUser = user;
                                    break; // Exit the loop once a match is found
                                }
                            }
                            // Check if a user with the selected value was found
                            if (selectedUser != null) {
                                // Set the selected user in your task object
                                task.setUsers(selectedUser);
                            } else {
                                // Handle the case where no matching user is found
                                Toast.makeText(getContext(), "No user found with the selected value", Toast.LENGTH_SHORT).show();
                            }

                        }

                        ArrayList<Department> selectedDepartments = new ArrayList<>();

                        //Department
                        if (CurrentUser.getRoleName().equals("HOD") || CurrentUser.getRoleName().equals("Teacher")) {
                            selectedDepartments.add(CurrentUser.getDepartment());
                        }
                        for (int j = 0; j < selectedbool.length; j++) {
                            if (selectedbool[j]) {
                                // Find the corresponding Department object based on the selected department name
                                String selectedDepartmentName = username1[j];
                                for (Department department : departmentArrayList) {
                                    if (department.getName().equals(selectedDepartmentName)) {
                                        selectedDepartments.add(department);
                                        break;
                                    }
                                }
                            }
                        }
                        task.setDepartment(selectedDepartments);
                        if (selectedFileUri != null) {
                            uploadFileToFirebase(selectedFileUri, task);
                        } else {
                            insertTask(task);
                        }
                        dialog.dismiss();
                    } catch (Exception exception) {
                        Toast.makeText(getContext(), exception.getMessage().toString(), Toast.LENGTH_LONG).show();
                    }
                }
            });

        } catch (Exception exception) {
            Toast.makeText(getContext(), exception.getMessage().toString(), Toast.LENGTH_LONG).show();
        }
    }
    private void fetchDepartments() {
        database.getReference().child("Department").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                departmentArrayList.clear();
                departmentNameArrayList.clear();
                for (DataSnapshot data : snapshot.getChildren()) {
                    Department department = data.getValue(Department.class);
                    if (department != null) {
                        departmentArrayList.add(department);
                        departmentNameArrayList.add(department.getName());
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle errors here
            }
        });
    }
    public void dialogClose(View view){
        dialog.dismiss();
    }
    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*"); // All file types
        intent.addCategory(Intent.CATEGORY_OPENABLE);

        startActivityForResult(intent, REQUEST_FILE_PICKER);
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if (requestCode == REQUEST_FILE_PICKER && resultCode == -1) {
                if (data != null) {
                    selectedFileUri = data.getData();
                    // Now you have the URI of the selected file, and you can proceed with file upload.

                    String selectedFileName = getFileNameFromUri(selectedFileUri);
                    selectedFileTextView.setText("Selected File: " + selectedFileName);
                }
            }
        } catch (Exception exception) {
            Toast.makeText(getContext(), exception.getMessage().toString(), Toast.LENGTH_SHORT).show();
        }
    }
    private void showDatePickerDialog(final EditText editText) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                getContext(),
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(android.widget.DatePicker view, int year, int month, int dayOfMonth) {
                        // The selected date is returned here
                        String selectedDate = year + "-" + (month + 1) + "-" + dayOfMonth;
                        editText.setText(selectedDate);
                    }
                },
                year, month, day
        );
        datePickerDialog.show();
    }
    private String getFileNameFromUri(Uri uri) {
        String fileName = "";
        if (uri.getScheme().equals("content")) {
            ContentResolver contentResolver = requireContext().getContentResolver();
            Cursor cursor = contentResolver.query(uri, null, null, null, null);
            try {
                if (cursor != null && cursor.moveToFirst()) {
                    int displayNameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    fileName = cursor.getString(displayNameIndex);
                }
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        return fileName;
    }
    private void insertTask(Task task){
        DatabaseReference taskRef = database.getReference().child("Task");
        // Use push() to generate a unique ID and set the department under that ID
        DatabaseReference newDepartmentRef = taskRef.push();
        task.setId(newDepartmentRef.getKey().toString());
        // Set the department data
        newDepartmentRef.setValue(task);
        Toast.makeText(getContext(), "Task added successfully", Toast.LENGTH_SHORT).show();
    }
    private void uploadFileToFirebase(Uri fileUri, final Task task) {
        StorageReference FileFolder = FirebaseStorage.getInstance().getReference().child("your_folder");
        StorageReference fileRef = FileFolder.child("file" + fileUri.getLastPathSegment());

        // Upload the file to Firebase Storage
        fileRef.putFile(fileUri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        // File successfully uploaded, now get the download URL
                        fileRef.getDownloadUrl()
                                .addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri downloadUrl) {
                                        // 'downloadUrl' contains the URL of the uploaded file
                                        String fileUrl = downloadUrl.toString();
                                        // Set the file URL in the task object
                                        task.setFileUrl(fileUrl);
                                        insertTask(task);
                                        Toast.makeText(getContext(), "File uploaded successfully. URL: " + fileUrl, Toast.LENGTH_SHORT).show();
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        // Handle the failure to get the download URL
                                        Toast.makeText(getContext(), "Failed to get download URL: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                    }
                                });
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // Handle the failure to upload the file
                        Toast.makeText(getContext(), "File upload failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    public void TaskDialogClose(){
        dialog.dismiss();
    }


}