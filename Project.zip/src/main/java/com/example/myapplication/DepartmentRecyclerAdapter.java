package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.Model.Department;
import com.example.myapplication.Model.Task;

import java.util.List;

public class DepartmentRecyclerAdapter  extends RecyclerView.Adapter<DepartmentRecyclerAdapter.myviewholder> {
    public Context context;
    private List<Department> dataholder;

    public  DepartmentRecyclerAdapter(Context context,List<Department> dataholder){
        this.dataholder = dataholder;
        this.context = context;
    }

    @NonNull
    @Override
    public DepartmentRecyclerAdapter.myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.department_row_item,parent,false);
        return new DepartmentRecyclerAdapter.myviewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DepartmentRecyclerAdapter.myviewholder holder, int position) {
        holder.DepartmentName.setText(dataholder.get(position).getName());
    }

    @Override
    public int getItemCount() {
        return dataholder.size();
    }
    class myviewholder extends RecyclerView.ViewHolder
    {
        TextView DepartmentName;
        public myviewholder(@NonNull View itemView)
        {
            super(itemView);
            DepartmentName=(TextView)itemView.findViewById(R.id.Department_name_row_item);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                    Intent intent = new Intent(context, DepartmentAllTask.class);
                    intent.putExtra("DepartmentId",dataholder.get(getAdapterPosition()).getName());
                    context.startActivity(intent);
                    }catch (Exception exception){
                        Toast.makeText(context, exception.getMessage().toString(), Toast.LENGTH_SHORT).show();
                    }
                }
            });

        }
    }
}
